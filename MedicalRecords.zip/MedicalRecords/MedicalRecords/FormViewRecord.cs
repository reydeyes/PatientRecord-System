﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static MedicalRecords.FormMain;

namespace MedicalRecords
{
    public partial class FormViewRecord : Form
    {
        SqlDataAdapter sqlda = new SqlDataAdapter();
        SqlConnection con = new SqlConnection(@"Data Source=RAYMOND-BERIN;Initial Catalog=TestDB_HRN;Integrated Security=True");
        string msg = "Patient Record Successfully Saved";
        string msg1 = "Record Failed to save";
        FormViewRecord obj = (FormViewRecord)Application.OpenForms["FormViewRecord"];
        //AddPatRec add = new AddPatRec();
        public FormViewRecord()
        {

            InitializeComponent();
            DisplayCombo();
            
        }

        public void LoadRec(int ID)
        {/*Load History Record*/
            DatePickerCustom();
            sqlda = new SqlDataAdapter("PatientRecView", con);
            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlda.SelectCommand.Parameters.Add("@patID", SqlDbType.Int).Value = ID;
            DataSet ds = new DataSet();
            sqlda.Fill(ds, "PatientRecView");
            data_record.DataSource = ds.Tables["PatientRecView"];
            data_record.Columns[0].Width = 180;
            data_record.Columns[1].Width = 180;
            data_record.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            data_record.Columns[3].Width = 190;
        }
        public void AddRec(int ID)
        {/*Add History Records
            Temporary Codes!
             */
            try
            {
                con.Open();
                sqlda = new SqlDataAdapter("PatientNewRec", con);
                sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlda.SelectCommand.Parameters.Add("@patID", SqlDbType.Int).Value = ID;
                sqlda.SelectCommand.Parameters.Add("@admission", SqlDbType.DateTime).Value = date_admission.Value;
                sqlda.SelectCommand.Parameters.Add("@discharge", SqlDbType.DateTime).Value = date_discharge.Value;
                sqlda.SelectCommand.Parameters.Add("@diagnosis", SqlDbType.VarChar,(50)).Value = tb_diagnosis.Text;
                sqlda.SelectCommand.Parameters.Add("@physician", SqlDbType.NVarChar, (50)).Value = cb_physician.Text.ToString();
                if (sqlda.SelectCommand.ExecuteNonQuery() == 1)

                {
                    LoadRec(ID);
                    clear();
                    MessageBox.Show(msg);
                }
                else
                {
                    MessageBox.Show(msg1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message+" ID Selected: " +ID);
            }
            finally
            {
                con.Close();
            }
        }
        void clear()//Clear Textboxes
        {
            DatePickerCustom();
            tb_diagnosis.Text = "";
        }
    

        void DisplayCombo()/*Populate ComboBox*/
        {

            sqlda = new SqlDataAdapter("select * from consultants", con);
            DataSet ds = new DataSet();
            sqlda.Fill(ds, "consultants");
            cb_physician.DataSource = ds.Tables["consultants"];
            cb_physician.DisplayMember = "FullName";
            cb_physician.ValueMember = "ID";
            this.cb_physician.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        void DatePickerCustom()
        {
            date_admission.CustomFormat = " ";
            date_admission.Format = DateTimePickerFormat.Custom;
            date_discharge.CustomFormat = " ";
            date_discharge.Format = DateTimePickerFormat.Custom;
        }
        private void date_admission_ValueChanged(object sender, EventArgs e)
        {
            date_admission.CustomFormat = "MM/dd/yyyy hh:mm tttt";
        }
        private void date_discharge_ValueChanged(object sender, EventArgs e)
        {
            date_discharge.CustomFormat = "MM/dd/yyyy hh:mm tttt";
        }

        private void btn_accept_Click(object sender, EventArgs e)
        {
            int id = int.Parse(tb_id.Text);
            AddRec(id);
            this.data_record.Update();
            this.data_record.Refresh();
            //Console.WriteLine(add.PatID + "id in textbox: " + tb_id);
            //Console.WriteLine("This is your ID: " + id);
            

        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            data_record.Update();
            data_record.Refresh();
        }
    }
}



﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace MedicalRecords
{
    public partial class FormPatient : Form
    {
        
        SqlDataAdapter sqlda;
        SqlConnection con = new SqlConnection(@"Data Source=RAYMOND-BERIN;Initial Catalog=TestDB_HRN;Persist Security Info=True;User ID=sa;Password=pogs1233");
        SqlCommand cmd;
        string msg = "Patient Successfully Recorded";
        string msg1 = "Failed to Record your Query";
        FormMain obj = (FormMain)Application.OpenForms["FormMain"];
        FormMain fm = new FormMain();
        public FormPatient()
        {
            InitializeComponent();
        }

        private void btn_sumbit_Click(object sender, EventArgs e)
        {
            executeMyQuery("PatientNew");
            obj.GridFill();
            fm.data_patient.Update();
            fm.data_patient.Refresh();
        }
        
        public void OpenConnection()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        public void CloseConnection()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        public void executeMyQuery(string query)
        {
            
            try
            {
                
                OpenConnection();
                sqlda = new SqlDataAdapter("PatientNew", con);
                sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlda.SelectCommand.Parameters.Add("@hrn", SqlDbType.VarChar, (10)).Value = tb_hrn.Text;
                sqlda.SelectCommand.Parameters.Add("@lastname", SqlDbType.VarChar, (50)).Value = tb_lastname.Text;
                sqlda.SelectCommand.Parameters.Add("@firstname", SqlDbType.VarChar,(50)).Value = tb_firstname.Text;
                sqlda.SelectCommand.Parameters.Add("@middlename", SqlDbType.VarChar, (50)).Value = tb_middlename.Text;
                sqlda.SelectCommand.Parameters.Add("@gender", SqlDbType.VarChar, (10)).Value = cb_gender.Text;
                sqlda.SelectCommand.Parameters.Add("@birthday", SqlDbType.Date).Value = date_birthday.Value.Date;
                sqlda.SelectCommand.Parameters.Add("@address", SqlDbType.Text).Value = tb_address.Text;
                sqlda.SelectCommand.Parameters.Add("@isdead", SqlDbType.Bit).Value = check_isdead.Checked;
                

                if (sqlda.SelectCommand.ExecuteNonQuery() == 1)
                {
                    Clear();
                    MessageBox.Show(msg);
                }
                else
                {
                    MessageBox.Show(msg1);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }
        void Clear()
        {
            tb_hrn.Text = String.Empty;
            tb_lastname.Text = String.Empty;
            tb_firstname.Text = String.Empty;
            tb_middlename.Text = String.Empty;
            cb_gender.Text = String.Empty;
            date_birthday.Text = String.Empty;
            tb_address.Text = String.Empty;
            check_isdead.Checked = false;
        }
    }
}

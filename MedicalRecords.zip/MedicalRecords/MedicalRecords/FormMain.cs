﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MedicalRecords
{
    public partial class FormMain : Form
    {
        SqlDataAdapter sqlda;
        SqlConnection con = new SqlConnection(@"Data Source=RAYMOND-BERIN;Initial Catalog=TestDB_HRN;Integrated Security=True");
        SqlCommand cmd;
        public int rowIndex;
        public FormMain()
        {
            con.Open();
            InitializeComponent();
            GridFill();
        }
        public void GridFill()
        {
            sqlda = new SqlDataAdapter("select * from vPatientLists", con);
            DataSet ds = new DataSet();
            sqlda.Fill(ds, "vPatientLists");
            data_patient.DataSource = ds.Tables["vPatientLists"];
            data_patient.Columns[0].Visible = false;
            data_patient.Columns[1].Width = 50;
            data_patient.Columns[2].Width = 250;
            data_patient.Columns[3].Width = 50;
            data_patient.Columns[4].Width = 70;
            data_patient.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            data_patient.Columns[6].Width = 45;
        }
        
        void search()
        {/*Search Value in data*/
            sqlda = new SqlDataAdapter("PatientSearch", con);
            sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlda.SelectCommand.Parameters.AddWithValue("@searchvalue", tb_search.Text);
            DataTable dttable = new DataTable();
            sqlda.Fill(dttable);
            data_patient.DataSource = dttable;
        }

        bool deletePatient(int ID)
        {/*Delete Patient*/
            using (sqlda = new SqlDataAdapter("PatientDel", con))
            {
                sqlda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlda.SelectCommand.Parameters.Add("@id", SqlDbType.Int).Value = ID;

                if (sqlda.SelectCommand.ExecuteNonQuery() > 0)
                {
                   
                    return true;

                }
                else
                    return false;
            }
        }
        public class AddPatRec
        {
            private int patID;

            public int PatID
            {
                get
                {
                    return patID;
                }
                set
                {
                    patID = value;
                }
            }
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            FormPatient patient = new FormPatient();
            patient.ShowDialog();
        }

        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            search();
        }
        private void btn_refresh_Click(object sender, EventArgs e)
        {
            data_patient.Update();
            data_patient.Refresh();
        }

        private void addPatientRecordToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            /*Add Record for each patient*/
            FormViewRecord vr = new FormViewRecord();
            AddPatRec add = new AddPatRec();

            if (data_patient.Rows.Count > 0)
            {
                int PatID = Convert.ToInt32(data_patient.Rows[rowIndex].Cells[0].Value.ToString());
                vr.tb_fullname.Text = data_patient.Rows[rowIndex].Cells[2].Value.ToString();
                vr.tb_id.Text = data_patient.Rows[rowIndex].Cells[0].Value.ToString();
                vr.LoadRec(PatID);
                add.PatID = PatID;
                //Console.WriteLine(PatID);
                vr.ShowDialog();
            }
        }

      

        private void data_patient_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {/*ID getter*/
            if (e.Button == MouseButtons.Right)
            {
                this.data_patient.Rows[e.RowIndex].Selected = true;
                this.rowIndex = e.RowIndex;
                this.context_menu.Show(this.data_patient, e.Location);
                this.context_menu.Show(Cursor.Position);
                //Console.WriteLine(this.rowIndex);
            }
            else
            {
                this.rowIndex = 0;
            }

        }

        private void delPatient_Click(object sender, EventArgs e)
        {/*Delete Patient*/
            if (data_patient.Rows.Count > 0)
            {
                if (!this.data_patient.Rows[rowIndex].IsNewRow)
                {
                    int PatID = Convert.ToInt32(this.data_patient.Rows[rowIndex].Cells[0].Value);
                    if (deletePatient(PatID))
                    {
                        GridFill();
                    }
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {/*Delete Patient*/
            if (data_patient.Rows.Count > 0)
            {
                if (!this.data_patient.Rows[rowIndex].IsNewRow)
                {
                    int PatID = Convert.ToInt32(this.data_patient.Rows[rowIndex].Cells[0].Value);
                    if (deletePatient(PatID))
                    {
                        GridFill();
                    }
                }

            }
        }

        private void UpdatePatient_Click(object sender, EventArgs e)
        {


        }

        private void btn_view_Click(object sender, EventArgs e)
        { /*View Patient Record*/
            FormViewRecord vr = new FormViewRecord();

            if (data_patient.SelectedRows.Count > 0)
            {
                int PatID = Convert.ToInt32(data_patient.SelectedRows[rowIndex].Cells[0].Value.ToString());
                vr.tb_fullname.Text = data_patient.SelectedRows[rowIndex].Cells[2].Value.ToString();
                vr.LoadRec(PatID);
                vr.btn_accept.Visible = false;
                vr.btn_cancel.Visible = false;
                vr.tb_diagnosis.Enabled = false;
                vr.cb_physician.Enabled = false;
                vr.date_admission.Enabled = false;
                vr.date_discharge.Enabled = false;
                vr.ShowDialog();
                //Console.WriteLine(PatID);
                //Console.WriteLine(rowIndex);
            }
           


        }


    }
}
    
    
    



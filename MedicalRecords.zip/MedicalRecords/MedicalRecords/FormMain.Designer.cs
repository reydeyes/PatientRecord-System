﻿namespace MedicalRecords
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.data_patient = new System.Windows.Forms.DataGridView();
            this.context_menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addPatientRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.delPatient = new System.Windows.Forms.ToolStripMenuItem();
            this.updatePatient = new System.Windows.Forms.ToolStripMenuItem();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.btn_new = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_selectall = new System.Windows.Forms.Button();
            this.btn_refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_patient)).BeginInit();
            this.context_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // data_patient
            // 
            this.data_patient.AllowUserToAddRows = false;
            this.data_patient.AllowUserToDeleteRows = false;
            this.data_patient.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.data_patient.BackgroundColor = System.Drawing.Color.SeaShell;
            this.data_patient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_patient.ContextMenuStrip = this.context_menu;
            this.data_patient.Location = new System.Drawing.Point(14, 42);
            this.data_patient.Name = "data_patient";
            this.data_patient.ReadOnly = true;
            this.data_patient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_patient.Size = new System.Drawing.Size(826, 369);
            this.data_patient.TabIndex = 7;
            this.data_patient.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.data_patient_CellMouseUp);
            // 
            // context_menu
            // 
            this.context_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPatientRecordToolStripMenuItem,
            this.delPatient,
            this.updatePatient});
            this.context_menu.Name = "context_menu";
            this.context_menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.context_menu.Size = new System.Drawing.Size(177, 70);
            // 
            // addPatientRecordToolStripMenuItem
            // 
            this.addPatientRecordToolStripMenuItem.Name = "addPatientRecordToolStripMenuItem";
            this.addPatientRecordToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.addPatientRecordToolStripMenuItem.Text = "Add Patient Record";
            this.addPatientRecordToolStripMenuItem.Click += new System.EventHandler(this.addPatientRecordToolStripMenuItem_Click);
            // 
            // delPatient
            // 
            this.delPatient.Name = "delPatient";
            this.delPatient.Size = new System.Drawing.Size(176, 22);
            this.delPatient.Text = "Delete Patient";
            this.delPatient.Click += new System.EventHandler(this.delPatient_Click);
            // 
            // updatePatient
            // 
            this.updatePatient.Name = "updatePatient";
            this.updatePatient.Size = new System.Drawing.Size(176, 22);
            this.updatePatient.Text = "Update Patient";
            this.updatePatient.Click += new System.EventHandler(this.UpdatePatient_Click);
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.Location = new System.Drawing.Point(419, 14);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(340, 22);
            this.tb_search.TabIndex = 0;
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // btn_new
            // 
            this.btn_new.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Location = new System.Drawing.Point(176, 11);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(75, 25);
            this.btn_new.TabIndex = 3;
            this.btn_new.Text = "New";
            this.btn_new.UseVisualStyleBackColor = true;
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit.Location = new System.Drawing.Point(95, 12);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(75, 25);
            this.btn_edit.TabIndex = 2;
            this.btn_edit.Text = "Edit";
            this.btn_edit.UseVisualStyleBackColor = true;
            // 
            // btn_view
            // 
            this.btn_view.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.Location = new System.Drawing.Point(14, 11);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(75, 25);
            this.btn_view.TabIndex = 1;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = true;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(257, 12);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 25);
            this.btn_delete.TabIndex = 4;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_selectall
            // 
            this.btn_selectall.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_selectall.Location = new System.Drawing.Point(338, 12);
            this.btn_selectall.Name = "btn_selectall";
            this.btn_selectall.Size = new System.Drawing.Size(75, 25);
            this.btn_selectall.TabIndex = 5;
            this.btn_selectall.Text = "Select All";
            this.btn_selectall.UseVisualStyleBackColor = true;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_refresh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refresh.Location = new System.Drawing.Point(765, 12);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 25);
            this.btn_refresh.TabIndex = 6;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 423);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.btn_selectall);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_view);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_new);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.data_patient);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Medical Record System";
            ((System.ComponentModel.ISupportInitialize)(this.data_patient)).EndInit();
            this.context_menu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.DataGridView data_patient;
        public System.Windows.Forms.TextBox tb_search;
        public System.Windows.Forms.Button btn_new;
        public System.Windows.Forms.Button btn_edit;
        public System.Windows.Forms.Button btn_view;
        public System.Windows.Forms.Button btn_delete;
        public System.Windows.Forms.Button btn_selectall;
        private System.Windows.Forms.ContextMenuStrip context_menu;
        private System.Windows.Forms.ToolStripMenuItem addPatientRecordToolStripMenuItem;
        public System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.ToolStripMenuItem delPatient;
        public System.Windows.Forms.ToolStripMenuItem updatePatient;
    }
}


﻿namespace MedicalRecords
{
    partial class FormViewRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.data_record = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.date_admission = new System.Windows.Forms.DateTimePicker();
            this.date_discharge = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_diagnosis = new System.Windows.Forms.TextBox();
            this.cb_physician = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_fullname = new System.Windows.Forms.TextBox();
            this.btn_accept = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.btn_refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_record)).BeginInit();
            this.SuspendLayout();
            // 
            // data_record
            // 
            this.data_record.AllowUserToAddRows = false;
            this.data_record.AllowUserToDeleteRows = false;
            this.data_record.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.data_record.BackgroundColor = System.Drawing.Color.SeaShell;
            this.data_record.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_record.Location = new System.Drawing.Point(16, 112);
            this.data_record.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.data_record.Name = "data_record";
            this.data_record.ReadOnly = true;
            this.data_record.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_record.Size = new System.Drawing.Size(817, 342);
            this.data_record.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(490, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Patient Full Name";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Admission";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Discharge";
            // 
            // date_admission
            // 
            this.date_admission.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.date_admission.CustomFormat = "MM/dd/yyyy hh:mm tt";
            this.date_admission.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_admission.Location = new System.Drawing.Point(40, 29);
            this.date_admission.Name = "date_admission";
            this.date_admission.Size = new System.Drawing.Size(178, 25);
            this.date_admission.TabIndex = 1;
            this.date_admission.ValueChanged += new System.EventHandler(this.date_admission_ValueChanged);
            // 
            // date_discharge
            // 
            this.date_discharge.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.date_discharge.CustomFormat = "MM/dd/yyyy hh:mm tt";
            this.date_discharge.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_discharge.Location = new System.Drawing.Point(40, 80);
            this.date_discharge.Name = "date_discharge";
            this.date_discharge.Size = new System.Drawing.Size(178, 25);
            this.date_discharge.TabIndex = 2;
            this.date_discharge.ValueChanged += new System.EventHandler(this.date_discharge_ValueChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(225, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Diagnosis";
            // 
            // tb_diagnosis
            // 
            this.tb_diagnosis.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tb_diagnosis.Location = new System.Drawing.Point(246, 29);
            this.tb_diagnosis.Multiline = true;
            this.tb_diagnosis.Name = "tb_diagnosis";
            this.tb_diagnosis.Size = new System.Drawing.Size(238, 76);
            this.tb_diagnosis.TabIndex = 3;
            // 
            // cb_physician
            // 
            this.cb_physician.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.cb_physician.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cb_physician.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.cb_physician.FormattingEnabled = true;
            this.cb_physician.Location = new System.Drawing.Point(562, 29);
            this.cb_physician.Name = "cb_physician";
            this.cb_physician.Size = new System.Drawing.Size(267, 25);
            this.cb_physician.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(490, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Attending Physician";
            // 
            // tb_fullname
            // 
            this.tb_fullname.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tb_fullname.Location = new System.Drawing.Point(562, 80);
            this.tb_fullname.Name = "tb_fullname";
            this.tb_fullname.ReadOnly = true;
            this.tb_fullname.Size = new System.Drawing.Size(267, 25);
            this.tb_fullname.TabIndex = 5;
            // 
            // btn_accept
            // 
            this.btn_accept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_accept.Location = new System.Drawing.Point(710, 461);
            this.btn_accept.Name = "btn_accept";
            this.btn_accept.Size = new System.Drawing.Size(119, 34);
            this.btn_accept.TabIndex = 7;
            this.btn_accept.Text = "Apply";
            this.btn_accept.UseVisualStyleBackColor = true;
            this.btn_accept.Click += new System.EventHandler(this.btn_accept_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_cancel.Location = new System.Drawing.Point(562, 461);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(119, 34);
            this.btn_cancel.TabIndex = 6;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(535, 80);
            this.tb_id.Name = "tb_id";
            this.tb_id.ReadOnly = true;
            this.tb_id.Size = new System.Drawing.Size(21, 25);
            this.tb_id.TabIndex = 9;
            this.tb_id.Visible = false;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_refresh.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refresh.Location = new System.Drawing.Point(12, 461);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 25);
            this.btn_refresh.TabIndex = 10;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // FormViewRecord
            // 
            this.AcceptButton = this.btn_accept;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_cancel;
            this.ClientSize = new System.Drawing.Size(845, 502);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_accept);
            this.Controls.Add(this.tb_fullname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cb_physician);
            this.Controls.Add(this.tb_diagnosis);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.date_discharge);
            this.Controls.Add(this.date_admission);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.data_record);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormViewRecord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Patient History Records";
            ((System.ComponentModel.ISupportInitialize)(this.data_record)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.DataGridView data_record;
        public System.Windows.Forms.DateTimePicker date_admission;
        public System.Windows.Forms.DateTimePicker date_discharge;
        public System.Windows.Forms.TextBox tb_diagnosis;
        public System.Windows.Forms.ComboBox cb_physician;
        public System.Windows.Forms.TextBox tb_fullname;
        public System.Windows.Forms.Button btn_accept;
        public System.Windows.Forms.Button btn_cancel;
        public System.Windows.Forms.TextBox tb_id;
        public System.Windows.Forms.Button btn_refresh;
    }
}